module.exports = {
    ScrapBCA : require('./lib/bank/BCA.class.js'),
    ScrapMandiri : require('./lib/bank/MANDIRI.class.js'),
}